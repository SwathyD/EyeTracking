var cards = new Array();

cards[0] = new make_card("edge", "jpg", "New Microsoft Edge logo", "A new browser deserves a new logo, and Microsoft has revealed a radically refreshed bit of artwork to go alongside the Chromium-based version of Microsoft Edge...");
cards[1] = new make_card("graphene", "jpg", "Graphene Batteries", "It (Graphene) is a potent conductor of electrical and thermal energy, extremely lightweight chemically inert, and flexible with a large surface area. It is also considered eco-friendly and sustainable, it is a wonder material...");
cards[2] = new make_card("ai", "jpg", "10 Charts That Will Change Your Perspective Of AI In Security", "Rapid advances in AI and machine learning are defining cybersecurity’s future daily. Identities are the new security perimeter and Zero Trust Security frameworks are capitalizing on AI’s insights to...");
cards[3] = new make_card("game", "png", "Who’s up for some zombicide?", "Mumbai’s got a new virtual reality gaming zone. Spend your day fighting zombies or walking on curvy, twisted paths in an amusing, virtual world..");

for(var a = 0; a <= 3; a++)
{
	add_elem(cards[a], a);
}

for(var a = 0; a <= 3; a++){
	document.getElementById('card_'+a).addEventListener("click", page_up, false);
}

// FLASH ARTICLES

news[1] = "Apple Says It Will Spend $2.5 Billion on Housing Crunch in the US";
news[2] = "Jio Fiber Showed Most Fluctuation in Internet Speeds in Q2 and Q3: Ookla";
news[3] = "BlueKeep Attacks Being Carried Out ‘On a Mass Scale’ on Windows Machines";
news[4] = "ISRO Working to Demonstrate Soft Landing on Moon: Chief";
news[5] = "Vivo S5 Leaked Image Hints at Hole-Punch Display, Slim All-Round Bezels";
news[6] = "China Gets Into Blockchain Race With the US";
news[7] = "Mi Note 10 Launching on November 6, Penta Camera Setup Detailed";
news[8] = "IT Ministry Said to Have Found Gaps in WhatsApp Reply on Spyware Issue";
news[9] = "Facebook was in talks to buy Fitbit before Google struck a deal";

flash_controller();