// change_time();

document.addEventListener("DOMContentLoaded", function(){
	setTimeout(function(){
		document.getElementById('body').style.opacity = "1";
	}, 0);
}, false);

document.getElementById('arrow').addEventListener('click', turn_back, false);

function change_time()
{ 
	document.getElementById('month').textContent = check_month(month());
	document.getElementById('date').textContent = date();
	document.getElementById('day').textContent = check_day(day());
	document.getElementById('hours').textContent = hours();
	document.getElementById('minutes').textContent = minutes();

	setTimeout(function(){
		change_time();
	}, 2000);
}

function on()
{
	localStorage.setItem('dev_ops', 'on');
	turn_back();
}

function off()
{
	localStorage.setItem('dev_ops', 'off');
	turn_back();
}

function turn_back()
{
	var body = document.getElementById('body');

	body.style.transitionDuration = "0.3s";

	body.style.height = "80%";
	body.style.width = "80%";

	body.style.opacity = "0";
	body.style.top = "10%";
	body.style.right = "10%";
	body.style.bottom = "10%";
	body.style.left = "10%";
	
	
	setTimeout(function(){
		redirect('index.html');
	}, 300);
}