var cards = new Array();

	cards[0] = new make_card("sb", "jpg", 'BJP Leaders in Favour of Re-Election in Maharashtra', "With the Shiv Sena seeming firm on its demand of sharing the chief minister's post in the next Maharashtra government, a BJP minister on Monday said some of his party leaders are willing for a re-election in the state.");
	cards[1] = new make_card("oddeven", "jpg", "AAP roles out even-odd", "Arvind Kejriwal, Satyendar Jan carpool to work on first day of Odd-Even scheme along with several other residents")
	cards[2] = new make_card("congress", "jpg", 'We Diluted Article 370 Twelve Times Without Controversy, Claims Congress', "The Congress on Sunday claimed it 'diluted and abrogated' Article 370 that granted special status to Jammu and Kashmiras many as twelve times..")
	cards[3] = new make_card("brazil_prez", "jpg", "Republic day guest", "The government is planning to invite Brazilian President Jair Bolsonaro as the chief guest to Republic Day celebrations next year, expanding its outreach to South America");

for(var a = 0; a <= 3; a++)
{
	add_elem(cards[a], a);
}

for(var a = 0; a <= 3; a++){
	document.getElementById('card_'+a).addEventListener("click", page_up, false);
}

// FLASH ARTICLES

news[1] = "Gian Chand Gupta unanimously elected Speaker of Haryana Assembly";
news[2] = "RCEP member countries split over deal for India";
news[3] = "Set up SIT to probe WhatsApp snooping issue, NCP tells Centre";
news[4] = "Assam, French Development Agency sign 50 million euro agreement to restore forest ecosystems";
news[5] = "India attaches importance to Myanmar's cooperation against insurgent groups: PM Modi to Suu Kyi";
news[6] = "SC draws the line on pollution crises, imposes hefty fines for dereliction";
news[7] = "Fadnavis in Delhi to meet Amit Shah";
news[8] = "Govt may accept NAGA museum demand showcasing 70 years of struggle";
news[9] = "Taking on Akhilesh, Priyanka, UP lists DHFL deal timeline";

flash_controller();