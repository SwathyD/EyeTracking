// HISTORIC FUNCTIONS
function redirect(link)
{
	window.location.assign(link);
}

function counter()
{
	if(localStorage.getItem(username()+'_action_counter'))	return (parseInt(localStorage.getItem(username()+'_action_counter')));
	else return 0;
}

function incr_counter(present)
{
	present++;
	localStorage.setItem(username()+'_action_counter', present);
}

function log_time()
{
	return (new Date().getTime());
}

function username()
{
	return (localStorage.getItem('username'));
}

function add_action_with_element(elem)
{
	localStorage.setItem(username()+'_'+'action_'+counter()+'_time', log_time());
	localStorage.setItem(username()+'_'+'action_'+counter()+'_type', elem.getAttribute('data-type'));
	localStorage.setItem(username()+'_'+'action_'+counter()+'_val', elem.getAttribute('data-val'));
	incr_counter(counter());
}

function add_action_with_string(type, val)
{
	localStorage.setItem(username()+'_'+'action_'+counter()+'_time', log_time());
	localStorage.setItem(username()+'_'+'action_'+counter()+'_type', type);
	localStorage.setItem(username()+'_'+'action_'+counter()+'_val', val);
	incr_counter(counter());
}


//	DATE & TIME FUNCTIONS
function check_day(day_no)
{
	if(day_no === 0) return "Sunday";
	if(day_no === 1) return "Monday";
	if(day_no === 2) return "Tuesday";
	if(day_no === 3) return "Wednesday";
	if(day_no === 4) return "Thursday";
	if(day_no === 5) return "Friday";
	if(day_no === 6) return "Saturday";
}

function check_month(mon_no)
{
	if(mon_no === 0) return "January";
	if(mon_no === 1) return "February";
	if(mon_no === 2) return "March";
	if(mon_no === 3) return "April";
	if(mon_no === 4) return "May";
	if(mon_no === 5) return "June";
	if(mon_no === 6) return "July";
	if(mon_no === 7) return "August";
	if(mon_no === 8) return "September";
	if(mon_no === 9) return "October";
	if(mon_no === 10) return "November";
	if(mon_no === 11) return "December";
}

function hours()
{
	return (new Date().getHours());
}

function minutes()
{
	return (new Date().getMinutes());
}

function day()
{
	return (new Date().getDay());
}

function month()
{
	return (new Date().getMonth());
}

function date()
{
	return (new Date().getDate());
} 

function year()
{
	return (new Date().getFullYear());
}

function time_online(name)
{
	var start = localStorage.getItem(name+'_start_time');
	return (parseInt(log_time())-parseInt(start));
}

function full_date()
{
	return (check_month(month())+" "+date()+", "+year());
}

function milli_to_sec(milli)
{
	return(parseInt(milli/1000));
}

function milli_to_min(milli)
{
	return (parseInt(milli_to_sec(milli)/60));
}

function formatted_time_online()
{
	var milli = time_online(username());
	var min = milli_to_min(milli);
	var sec = milli_to_sec(milli);
	sec = sec % 60;

	return (min+" min & "+sec+"s");
}

function format_this_time(milli)
{
	milli = (parseInt(milli) - parseInt(localStorage.getItem(username()+'_start_time')));

	var sec = milli_to_sec(milli);
	var min = milli_to_min(milli); 
	sec = sec % 60;

	if(min)	return (min+" min & "+sec+"s");	
	else return (sec+"s");
}