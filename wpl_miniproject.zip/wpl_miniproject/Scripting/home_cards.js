var card = new Array();

// PIC_NAME -- EXT -- HEADING -- SNIPPET

card[0] = new make_card("ai_iot", "jpg", "Using AI, IoT to deliver fresh food, cut wastage", "According to United Nation’s FAO (Food and Agriculture Organisation) roughly one third of the food produced in the world for human consumption every year (~1.3 billion tons) gets lost or wasted");
card[1] = new make_card("air_pol", "jpg", "Delhi Air Pollution LIVE Updates", "Delhi residents choose carpools over cabs on first day of Odd-Even scheme. AQI falls to 407 at 4 pm on Monday, air quality remains severe.");
card[2] = new make_card("attack", "webp", "1 killed, 25 injured in grenade attack", "One person was killed and 25 were injured in a grenade attack in a market in Jammu and Kashmir’s capital Srinagar on Monday. Police said the incident took place in a market in Maulana Azad Road.");
card[3] = new make_card("maha", "webp", "Cyclone Maha", "Cyclonic storm Maha is likely to bring very heavy rains to parts of Maharashtra during November 6 till 8, the India Meteorological Department(IIMD) said on Sunday.");
card[4] = new make_card("airtel", "jpg", 'Airtel’s new Rs 599 prepaid plan', "Airtel’s new Rs 599 prepaid plan comes with 2GB per day data, unlimited calls to any network, and 100 SMSes per day. The plan has a validity of 84 days and the insurance cover continues automatically for three months with every recharge. ");
card[5] = new make_card("isro", "jpg", "Upcoming Ventures of ISRO", "Know what the Indian Space Research Organisation is planning to achieve in the coming years...");
card[6] = new make_card("s11", "jpg", "Samsung Galaxy S11 to use second-gen 108 MP sensor", "We've had a good idea from early information that Samsung's Galaxy S11 will use the 108 MP ISOCELL Bright HMX sensor Samsung co-developed with Xiaomi...");


for(var a = 0; a <= 6; a++)
{
	add_elem(card[a], a);
}

for(var a = 0; a <= 6; a++){
	document.getElementById('card_'+a).addEventListener("click", page_up, false);
}

// FLASH ARTICLES

news[1] = "Today : "+ full_date();
news[2] = "Ambient Temperature : 36<sup>o</sup>C";
news[3] = "Ambient Weather : Humid, Sunny, Hot";
news[4] = "ISIS leader Abu Bakr al-Baghdadi killed";
news[5] = "Rains likely in parts of Maharashtra till November 7";
news[6] = "ICC bans Bangladesh captain Shakib";
news[7] = "Housefull 4 takes the top spot in the franchise";
news[8] = "395 strangers pool Rs 6 lak for the infant's bone marrow transplant";
news[9] = "Harayana assembly elections 2019: 42% candidates crorepatis, 10% have criminal cases.";