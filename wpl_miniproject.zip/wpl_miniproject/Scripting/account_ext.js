(function(){

var name_user, password_user, gender_user, age_user, email_user, profile_photo_user;  

var email_regex = /\w+[.#]?\w+@(gmail|ymail|hotmail|outlook|rediffmail)(\.com|\.in)/;

var plate_sign = 0;

var error_empty_string_sign = document.getElementById('empty_string_sign');
var error_special_char_sign = document.getElementById('special_char_sign');
var name_text_sign = document.getElementById('name_text_sign');
var username_box_sign = document.getElementById('username_sign');
username_box_sign.value = localStorage.getItem("username"); 

var button_nxt_sign = document.getElementById('button_nxt_sign');
var button_prev_sign = document.getElementById('button_prev_sign');
var button_wrapper = document.getElementById('button_wrapper_sign');

var male_img = document.getElementById('male');
var female_img = document.getElementById('female');
var skip_button = document.getElementById('skip_button');

var age = document.getElementById('age');

var pass_box1 = document.getElementById('password_sign_1');
var pass_box2 = document.getElementById('password_sign_2');

var email = document.getElementById("email");
var email_text = document.getElementById("email_text");

document.getElementById('button_nxt_welcome_page').addEventListener("click", function(){
		console.log("It fired!");
		document.getElementById('welcome_wrapper').style.opacity = "0";
		setTimeout(function(){
			document.getElementById('welcome_wrapper').style.display = "none";
		}, 500);

		plate_sign++;
}, false);

username_box_sign.addEventListener("keyup", function(){

	document.getElementById('known_username').style.opacity = "0";
	document.getElementById('known_username').style.display = "none";

	if(!this.value){
		error_empty_string_sign.style.opacity = "1";
		error_special_char_sign.style.display = "none";
		error_color_implementor(name_text_sign, username_box_sign);		
		return;
	}

	else error_empty_string_sign.style.opacity = "0";

	if(!this.value.match(regex))
	{
		error_special_char_sign.style.display = "none";
		correct_color_implementor(name_text_sign, username_box_sign);
	}

	else 
	{
		error_special_char_sign.style.display = "flex";
		error_special_char_sign.style.opacity = "1";
		error_color_implementor(name_text_sign, username_box_sign);
	}

}, false);

document.addEventListener("mousemove", function(){
	
	switch(plate_sign)
	{
		case 0:
				button_prev_sign.style.visibility = "hidden";
				button_nxt_sign.style.visibility = "hidden";
			break;

		case 1:
				button_wrapper.style.display = "flex";
				button_prev_sign.style.visibility = "hidden";
				button_nxt_sign.style.visibility = "visible";
			break;

		case 2:
					button_wrapper_sign.style.bottom = "-10%";
			break;

		case 3:
				button_wrapper.style.display = "flex";
				button_wrapper_sign.style.bottom = "0%";	
				button_prev_sign.style.visibility = "visible";
				button_nxt_sign.style.visibility = "visible";
			break;

		case 4:
		case 5:
				button_wrapper.style.display = "flex";
				button_prev_sign.style.visibility = "visible";
				button_nxt_sign.style.visibility = "visible";
			break;

		case 6:
		case 7:
				button_wrapper.style.display = "flex";
				button_prev_sign.style.visibility = "visible";
				button_nxt_sign.style.visibility = "visible";
			break;

		case 8:
				button_wrapper.style.display = "none";
			break;
	}
}, false);

button_nxt_sign.addEventListener("click", function(){
		
	console.log("moved plate"+plate_sign);

		switch(plate_sign)
		{
			case 1:
					name_plate_mover();
				break;

			case 3:
					age_plate_mover();
				break;

			case 4:
					pass_plate_one_mover();
				break;

			case 5:
					pass_plate_two_mover();
				break;

			case 6:
					email_plate_mover();
				break;

			case 7:
					final_plate_mover();
					
					localStorage.setItem('username', localStorage.getItem('sign_user_name_'+parseInt(localStorage.getItem('sign_user_ctr')-1)));

					add_action_with_string('self', 'Signed Up');
				break;
		}

}, false);

button_prev_sign.addEventListener("click", function(){

	switch(plate_sign)
	{
		case 7: 
				document.getElementById('email_wrapper').style.left = "0%"; 
				document.getElementById('final_look').style.opacity = "0";

				document.getElementById('profile_pic').getElementsByTagName('img')[0].remove();

			break;
		
		case 6:
				document.getElementById('pass_sign_retype_wrapper').style.left = "0%";
				document.getElementById('email_wrapper').style.opacity = "0";
			break;

		case 5:
				document.getElementById('pass_sign_retype_wrapper').style.left = "100%";
				document.getElementById('pass_sign_wrapper').style.left = "0%";
			break;

		case 4:
				document.getElementById("age_mapper_wrapper").style.left = "0%";
				document.getElementById('pass_sign_wrapper').style.opacity = "0";
			break;
		
		 case 3:
		
		 	document.getElementById("age_mapper_wrapper").style.opacity = "0";

			if(document.getElementById('gender_mapper_wrapper').style.left === "100%")
			{
				document.getElementById('gender_mapper_wrapper').style.left = "0%";
			}

			else
			{
				document.getElementById('gender_mapper_wrapper').style.zIndex = "10";
				document.getElementById('gender_mapper_wrapper').style.opacity = "1";	
			}

		 break;
	}

	plate_sign--;

}, false);

button_prev_sign.addEventListener("mouseout", function(){
	this.style.color = "rgba(0,0,0,0.6)";
	this.style.backgroundColor = "rgba(0,0,0,0.2)";
}, false);


male_img.addEventListener("click", function(){
	gender_user = this.id;

	female_img.style.filter = "blur(4px)";
	male_img.style.filter = "blur(0px)";

	setTimeout(function(){
		gender_plate_mover(0);
	}, 500);

}, false);

female_img.addEventListener("click", function(){
	gender_user = this.id;
	
	male_img.style.filter = "blur(4px)";
	female_img.style.filter  = "blur(0px)";

	setTimeout(function(){
		gender_plate_mover(0);
	}, 500);

}, false);

skip_button.addEventListener("click", function(){
	gender_user = "Not Specified";
	
	female_img.style.filter = "blur(4px)";
	male_img.style.filter = "blur(4px)";

	setTimeout(function(){
		gender_plate_mover(1);
	}, 500);


},false);

age.addEventListener("keyup",function(){

var error_young_age = document.getElementById('age_underflow');
var error_old_age = document.getElementById('age_overflow');
var error_empty_age = document.getElementById('empty_age');

error_young_age.style.display = "none";
error_young_age.style.opacity = "1";
error_old_age.style.display = "none";
error_old_age.style.opacity = "1";
error_empty_age.style.opacity = "0";

	this.style.borderBottom = "4px solid "+correct_color;

	if(this.value > 100) 
	{	
		error_old_age.style.display = "flex";
		this.value = null;
		this.style.borderBottom = "4px solid "+error_color;
	}

	if(this.value < 0) 	this.value = null; 

}, false);

pass_box1.addEventListener("keyup", function(){
	document.getElementById('empty_password_1').style.opacity = "0";
	correct_color_implementor(document.getElementById('pass_text_sign_1'), pass_box1);
}, false);

pass_box2.addEventListener("keyup", function(){
	document.getElementById('empty_password_2').style.display = "none";
	document.getElementById('unmatched_password').style.opacity = "0";
	correct_color_implementor(document.getElementById('pass_text_sign_2'), pass_box2);
}, false);

email.addEventListener("keyup", function(){
	document.getElementById("incorrect_email").style.opacity = "0";
	correct_color_implementor(email_text, email);
}, false);

function name_plate_mover()
{
	if(username_box_sign.value)
	{

		for(var a = 0; a < localStorage.getItem('sign_user_ctr'); a++)
		{
			if(localStorage.getItem('sign_user_name_'+a) === username_box_sign.value)
			{
				document.getElementById('known_username').style.display = "flex";
				document.getElementById('known_username').style.opacity = "1";
				error_color_implementor(name_text_sign, username_box_sign);
				console.log("returning");
				return;
			}
		}

		document.getElementById('name_wrapper_sign').style.left = "-100%";
		name_user = username_box_sign.value;
		document.getElementById('gender_mapper_wrapper').style.opacity = "1";
		plate_sign++;
	}

	else 
	{
		error_color_implementor(name_text_sign, username_box_sign);
	}
}

function gender_plate_mover(skip)
{
	if(!skip) 
	{
		document.getElementById('gender_mapper_wrapper').style.opacity = "0";
		
		setTimeout(function(){
			document.getElementById('gender_mapper_wrapper').style.zIndex = "0";
		}, 800);

		var error_young_age = document.getElementById('age_underflow');
		var error_old_age = document.getElementById('age_overflow');
		var error_empty_age = document.getElementById('empty_age');
		error_young_age.style.display = "none";
		error_young_age.style.opacity = "1";
		error_old_age.style.display = "none";
		error_old_age.style.opacity = "1";
		error_empty_age.style.opacity = "0";
	}

	else
	{
		document.getElementById('gender_mapper_wrapper').style.left = "100%";
	}
	
	document.getElementById('age_mapper_wrapper').style.opacity = "1";

	plate_sign++;
}

function age_plate_mover()
{
	if(age.value > 8)
	{
		document.getElementById("age_mapper_wrapper").style.left = "-100%";
		age_user = age.value;

		document.getElementById('pass_sign_wrapper').style.opacity = "1";
		plate_sign++;
	}

	else if(age.value >= 1)
	{
		document.getElementById('age_underflow').style.display = "flex";
		age.value = null;
		age.style.borderBottom = "4px solid "+error_color;
	}

	else
	{
		document.getElementById("empty_age").style.opacity = "1";
		age.style.borderBottom = "4px solid "+error_color;
	}

}

function pass_plate_one_mover()
{
	if(pass_box1.value)
	{
		document.getElementById('pass_sign_wrapper').style.left = "100%";
	
		setTimeout(function(){	
			document.getElementById('pass_sign_retype_wrapper').style.left = "0%";
		}, 800);

		plate_sign++;
	}

	else
	{
		document.getElementById('empty_password_1').style.opacity = "1";
		error_color_implementor(document.getElementById('pass_text_sign_1') , pass_box1);
	}
}

function pass_plate_two_mover()
{
	if(!pass_box2.value)
	{
		document.getElementById('empty_password_2').style.display = "flex";
		document.getElementById('empty_password_2').style.opacity = "1";
		error_color_implementor(document.getElementById('pass_text_sign_2'), pass_box2);
	}

	else if(pass_box1.value === pass_box2.value)
	{
		document.getElementById('pass_sign_retype_wrapper').style.left = "-100%";
		password_user = pass_box1.value;
		document.getElementById('email_wrapper').style.opacity = "1";
		plate_sign++;
	}

	else if(pass_box1.value != pass_box2.value)
	{
		document.getElementById('unmatched_password').style.opacity = "1";
		error_color_implementor(document.getElementById('pass_text_sign_2'), pass_box2);
	}
}

function email_plate_mover()
{
	if(email.value.match(email_regex) || !email.value)
	{
		document.getElementById('email_wrapper').style.left = "-100%";
		if(email.value)	email_user = email.value;
		else email_user = "Not Specified";

		console.log(email_user);
		document.getElementById('final_look').style.opacity = "1";
		data_analyzer();
		plate_sign++;
	}

	else
	{
		document.getElementById('incorrect_email').style.opacity = "1";
		error_color_implementor(email_text, email);
	}

}

function data_analyzer()
{
	if(age_user < 21)
	{
		if(gender_user == "male") profile_photo_user = "boy";
		else profile_photo_user = "girl";
	}

	else
	{
		if(gender_user == "male") profile_photo_user = "man";
		else profile_photo_user = "woman";
	}

	if(gender_user == "Not Specified") profile_photo_user = "none";
 	
 	var image = document.createElement("img");

 	image.setAttribute("src", "../Pics/Misc/"+profile_photo_user+".jpg");

 	document.getElementById('profile_pic').appendChild(image);

 	document.getElementById('name_place').textContent = name_user;
 	document.getElementById('gender_place').textContent = gender_user;
 	document.getElementById('age_place').textContent = age_user;
 	document.getElementById('email_id_place').textContent = email_user;
}

function final_plate_mover()
{
	document.getElementById('final_look').style.left = "-100%";
	document.getElementById('success_wrapper').style.opacity = "1";
	plate_sign++;

	var counter;

	if(localStorage.getItem("sign_user_ctr")) counter = localStorage.getItem("sign_user_ctr"); 
	else counter = 0;

	localStorage.setItem("sign_user_name_"+counter, name_user);
	localStorage.setItem("sign_user_pass_"+counter, password_user);
	localStorage.setItem("sign_user_email_"+counter, email_user);
	localStorage.setItem("sign_user_gender_"+counter, gender_user);
	localStorage.setItem("sign_user_age_"+counter, age_user);

	counter++;

	localStorage.setItem("sign_user_ctr", counter);
}

})();