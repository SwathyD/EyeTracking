// INTRO MOD AND THE SITE

var placeholder = document.getElementById('placeholder');
var box = document.getElementById("text_field"); 


// ASK FOR THE NAME IF THE NAME IS NOT STORED...

if(!localStorage.getItem("username"))
{
	box.addEventListener("blur", function(){
		this.focus()
	}, false)
	
	document.addEventListener('keydown', function(){
		check_submit(event, box);
	}, false)
}
else 
{
	mode_switch()
}

// CHANGING BACKGROUND

function check_submit(event, box) {
	if(event.keyCode == 13) 
	{
		localStorage.setItem("username", box.value);
		document.getElementById("flash").style.right = "-1000px";
		document.getElementById("flash").style.width = "-1000px";

		setTimeout(function(){
			document.getElementById("flash").style.height = "6000px";
			document.getElementById("flash").style.width = "6000px";
		}, 500);

		setTimeout(function(){
			document.getElementById("flash").style.right = "-1000px";
			document.getElementById("flash").style.bottom = "-1000px";
			document.getElementById("flash").style.top = "auto";
			document.getElementById("flash").style.left = "auto";
		}, 1000);

		setTimeout(function(){
			document.getElementById("flash").style.height = "0%";
			document.getElementById("flash").style.width = "0%";
		}, 2500);
		
		setTimeout(function(){
			mode_switch();
		}, 2200);
	}
}

//	SWITCH MODE BY SWAPPING THE DISPLAYS AND GIVE THE PLACEHOLDER THE USERNAME FROM THE STORAGE

function mode_switch() {
		document.getElementById('after_flash').style.display = "none";
		document.getElementById('body').className = "alive";
		
		if(!localStorage.getItem(username()+'_start_time')) localStorage.setItem(username()+'_start_time', log_time());
		
		add_action_with_string('nav', 'Home');
		if(!localStorage.getItem(username()+'_cards_read')) localStorage.setItem(username()+'_cards_read', '0');
		
		selection();
		flash_controller();
}

// localStorage.setItem('flag', "0");

// document.getElementById('card_click_content').addEventListener('scroll', function(){
// 	var threshold = document.getElementById('card_0_title').offsetHeight + document.getElementById('page_card_0').offsetTop+10;
// 	console.log(localStorage.getItem('flag'));
// 	if((this.scrollTop > threshold) && localStorage.getItem('flag') === "0")
// 	{
// 		console.log('expand');
// 		expand();
// 		localStorage.setItem('flag', "1");
// 	}

// 	if(this.scrollTop <= threshold && localStorage.getItem('flag') === "1")
// 	{
// 		console.log('collapse');
// 		collapse();
// 		localStorage.setItem('flag', "0");
// 	}
// }, false);

// localStorage.setItem('a', '0');
// var handle = setInterval(on_and_off, 5000);

function expand()
{
	var img = document.getElementById('about_img');
	var info = document.getElementById('info');
	var text = document.getElementById('textarea');

	img.style.display = "flex";
	info.style.display = "flex";

	setTimeout(function(){	
		img.style.opacity = "1";
		info.style.height = "20px";
	}, 0);

	localStorage.setItem('a', 0);

	img.addEventListener('click', on_and_off, false);
}

function on_and_off()
{
	var a = parseInt(localStorage.getItem('a'));
	text_invisible();
		setTimeout(close, 300);
		setTimeout(open, 900);
		setTimeout(function(){
			text_changer(infomercial[a]);
			text_visible();
		}, 1400);
		a++;
		if(a > 2) a = 0;

		localStorage.setItem('a', a);
}

// function on_and_off()
// {
// 	var a = parseInt(localStorage.getItem('a'));
// 		open();
		
// 		setTimeout(function(){
// 			text_changer(infomercial[a]);
// 			text_visible();
// 		}, 500);

// 		setTimeout(function(){
// 			text_invisible();
// 		}, 3500);

// 		setTimeout(function(){
// 			close();
// 		}, 3800);

// 		a++;
// 		if(a > 2) localStorage.setItem('a', '0');
// 		else localStorage.setItem('a', a);
// }

function collapse()
{
	var img = document.getElementById('about_img');
	var info = document.getElementById('info');
	var text = document.getElementById('textarea');	

	// img.removeEventListener('click', on_and_off);
	text_invisible();
	
	setTimeout(function(){
		close();
	}, 300);
	
	setTimeout(function(){
		info.style.height = "0px";
		img.style.opacity = "0";
	}, 900);

	setTimeout(function(){
		info.style.display = "none";
		img.style.display = "none";
	}, 1200);
}

var infomercial = new Array();

infomercial[0] = "The Next Gen Transport";
infomercial[1] = "By Bob Woodward";
infomercial[2] = "Published 31h ago";

function open()
{
	document.getElementById('info').style.width = "300px";
}

function close()
{
	document.getElementById('info').style.width = "0px";
}

function text_changer(string)
{
	document.getElementById('textarea').textContent = string;
}

function text_visible()
{
	document.getElementById('textarea').style.opacity = "1";
}

function text_invisible()
{
	document.getElementById('textarea').style.opacity = "0";
}

