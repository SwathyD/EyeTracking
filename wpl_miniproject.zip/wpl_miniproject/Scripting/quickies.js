	document.addEventListener("DOMContentLoaded", function(){
		setTimeout(function(){
			document.getElementById('body').style.opacity = "1";
		}, 0);

		setTimeout(function(){
			document.getElementById('intro').style.opacity = 0;
			document.body.requestFullscreen();
		}, 4500);
		
		setTimeout(function(){
			document.getElementById('intro').style.display = 'none';
		}, 5000);		

	}, false);

	document.addEventListener("keyup", function(event){
		switch(event.keyCode)
		{
			case 37 : screen_changer('right');
				break;
			
			case 38 : screen_changer('bottom'); 
				break;

			case 39 : screen_changer('left');  
				break;

			case 40	: screen_changer('top');
				break;
		
			case 27 : redirect('index.html');
				break; 
		}
	}, false);

	var screen = 0;
	var images = new Array();
	var a = 0;
	var lim = 9;

	images[0] = new Slide('theme0', 'jpg', 'ISIS Leader Abu Bakr Al Baghdadi dead claims US.');
	images[1] = new Slide('theme1', 'jpg', 'Drone captures the disparity between poor and rich in Mumbai.');
	images[2] = new Slide('theme2', 'jpg', "It's Halloween");
	images[3] = new Slide('theme3', 'jpg', 'Red Dead 2 is coming to PC November 5th.');
	images[4] = new Slide('theme4', 'jpg', 'Follow these 5 foods for a healthy gut.');
	images[5] = new Slide('theme5', 'jpg', 'Metro Bhavan construction started at Aarey.');
	images[6] = new Slide('theme6', 'jpg', 'BJP accused of EVM tampering');
	images[7] = new Slide('theme7', 'jpg', 'Crucial legislations lined up for winter session of parliament.');
	images[8] = new Slide('theme8', 'jpg', 'NASA conducts the first all woman spacewalk');
	images[9] = new Slide('theme9', 'jpg', 'Watch it exclusively on Amazon Prime Video');

	for(var a = 0; a <= lim; a++)
	{
		add_package(images[a], a);
	}

	function Slide(image, ext, text)
	{
		this.image_path = "../Pics/Backgrounds/"+image+"."+ext;
		this.caption = text;
	}

	function add_package(slide, index)
	{
		var package = document.createElement('div');
		package.className = "slide_wrapper";
		package.style.zIndex = 10 - index;
		package.style.transitionDuration = "0.5s";
		if(index === 2) package.id = "match"; 
		
		var caption_div = document.createElement('div');
		caption_div.id = 'theme'+index;
		caption_div.className = "caption_wrapper";

		package.style.backgroundImage = "url("+slide.image_path+")";
		caption_div.textContent = slide.caption;

		package.appendChild(caption_div);

		document.getElementById('body').appendChild(package);
	}

	function screen_changer(to)
	{	
		if(to === "left") 
		{
			document.getElementsByClassName('slide_wrapper')[screen].style.left = "-120%";
			document.getElementsByClassName('slide_wrapper')[screen].style.right = "120%";
		}	
		
		if(to === "top") 
		{	
			document.getElementsByClassName('slide_wrapper')[screen].style.top = "-120%";
			document.getElementsByClassName('slide_wrapper')[screen].style.bottom = "120%";
		}

		if(to === "right") 
		{	
			document.getElementsByClassName('slide_wrapper')[screen].style.right = "-120%";
			document.getElementsByClassName('slide_wrapper')[screen].style.left = "120%";
		}

		if(to === "bottom") 
		{	
			document.getElementsByClassName('slide_wrapper')[screen].style.bottom = "-120%";
			document.getElementsByClassName('slide_wrapper')[screen].style.top = "120%";
		}

		setTimeout(function(){
			incr_index();
			
		if(to === "left") 
		{
			document.getElementsByClassName('slide_wrapper')[screen].style.left = "0%";
			document.getElementsByClassName('slide_wrapper')[screen].style.right = "0%";
		}	
		
		if(to === "top") 
		{	
			document.getElementsByClassName('slide_wrapper')[screen].style.top = "0%";
			document.getElementsByClassName('slide_wrapper')[screen].style.bottom = "0%";
		}

		if(to === "right") 
		{	
			document.getElementsByClassName('slide_wrapper')[screen].style.right = "0%";
			document.getElementsByClassName('slide_wrapper')[screen].style.left = "0%";
		}

		if(to === "bottom") 
		{	
			document.getElementsByClassName('slide_wrapper')[screen].style.bottom = "0%";
			document.getElementsByClassName('slide_wrapper')[screen].style.top = "0%";
		}			

			
			screen++;
			if(screen === 10) screen = 0;
		
		}, 500);
	}

	function incr_index()
	{
		var slides = document.getElementsByClassName('slide_wrapper');
		var init = (screen+1 === 10)? 0:screen+1;

		slides[screen].style.zIndex = '1';



		for(var temp = init ;; temp++)
		{
			if(temp > lim)
			{
				temp = 0;
			}

			if(temp === screen) break;

			var prev = slides[temp].style.zIndex;
			prev++;
			if(prev > 10) break;
			slides[temp].style.zIndex = prev; 
		}
	}
