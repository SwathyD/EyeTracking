function add_elem(obj, index)
{
	var menu = document.getElementById("scroller_menu");
	
	var package = document.createElement("div");
	var img = document.createElement("div");
	var content_wrapper = document.createElement("div");
	var head = document.createElement("div");
	var content = document.createElement("div");

	img.className = "card_img";
	head.className = "card_head";
	content.className = "card_content";

	img.style.backgroundImage = "url("+obj.pic+")";
	head.textContent = obj.title;
	content.textContent = obj.snippet;
	package.id = "card_"+index;
	package.setAttribute("data-toggle", "modal");
	package.setAttribute("data-target", "#modal_card_"+index);

	content_wrapper.appendChild(head);
	content_wrapper.appendChild(content);
	package.appendChild(img);
	package.appendChild(content_wrapper);

	menu.appendChild(package);
}

function make_card(pic_name, ext, heading, intro)
{
	this.pic = "../Pics/Cards/"+pic_name+"."+ext;
	this.title = heading;
	this.snippet = intro;
}