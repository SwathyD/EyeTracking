var cards = new Array();

cards[0] = new make_card("srk", "webp", "Want to play good characters..: Shah Rukh Khan", "Shah Rukh Khan revealed that he wants to play some good characters on the big screen in the near future so that his youngest child gets to know why people love him.");
cards[1] = new make_card("bd", "jpg", 'Shah Rukh Khan birthday bash', "Salman Khan sends warm and funny birthday wish to Shah Rukh Khan: ‘Abey phone toh utha leta mera’");
cards[2] = new make_card("panipat", "jpg", "Panipat: Sanjay Dutt, Kriti Sanon, Arjun Kapoor's first looks revealed", "The makers of Arjun Kapoor's Panipat have just dropped the first look poster of Sanjay Dutt as Ahmad Shah Abdali, Kriti Sanon as Parvati Bai and Arjun Kapoor as Sadashivrao Bhau. Check them out!");
cards[3] = new make_card("pc", "jpg", "Why is Priyanka Chopra finding it hard to shoot in the capital?", "Priyanka Chopra is currently filming for The White Tiger in New Delhi, and shared an Instagram post sharing that it's difficult to shoot there because of the smog and pollution.");

for(var a = 0; a <= 3; a++)
{
	add_elem(cards[a], a);
}

for(var a = 0; a <= 3; a++){
	document.getElementById('card_'+a).addEventListener("click", page_up, false);
}

// FLASH ARTICLES

news[1] = "'Don't Triple-Seat': An Iconic Andaz Apna Apna Scene In Maharashtra Police's Tweet";
news[2] = "Ayushmann Khurrana On Meeting Amitabh Bachchan After Skipping Diwali Party: 'I Was A Bit Scared'";
news[3] = "Nach Baliye 9: And The Winners Are... Prince Narula And Yuvika Chaudhary";
news[4] = "On Shah Rukh Khan's Birthday, Dubai's Burj Khalifa Lit Up With A Birthday Wish For 'King Of Bollywood'";
news[5] = "Akshay Kumar's Laxmmi Bomb To Clash With Salman Khan's Radhe At The Box Office";
news[6] = "Ellen DeGeneres to Receive Carol Burnett Award at Golden Globes";
news[7] = "Oliva Newton-John's iconic Grease outfit sells at auction for $405,700";
news[8] = "'Terminator: Dark Fate' disappoints at box office";
news[9] = 'Harry Styles Wants to Play the Next James Bond';

flash_controller();