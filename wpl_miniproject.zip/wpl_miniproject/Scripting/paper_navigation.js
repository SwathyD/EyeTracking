
document.addEventListener("DOMContentLoaded", function(){
	
	setTimeout(function(){
		document.getElementById('body').style.opacity = "1";
	}, 0);
	
	appender();

	setTimeout(function(){

		for(var ctr = 0; ctr < 2; ctr++)
		{
			setTimeout(page_getter(ctr), 400);
		}

	}, 1400);

}, false);

function appender()
{	
	var tech = document.createElement("img");
	var buzz = document.createElement("img");
	
	tech.setAttribute("src", "../Pics/Misc/tech.png");
	buzz.setAttribute("src", "../Pics/Misc/buzz.png");

	tech.className = "item";
	buzz.className = "item";

	tech.setAttribute("onclick","window.open('techpage.html')")
	buzz.setAttribute("onclick","window.open('buzzpage.html')")

	document.getElementById("scroller_menu").appendChild(tech);
	document.getElementById("scroller_menu").appendChild(buzz);
}

function page_getter(ctr)
{
	document.getElementsByClassName('item')[ctr].style.opacity = "1";
	document.getElementsByClassName('item')[ctr].style.left = "0%";
}