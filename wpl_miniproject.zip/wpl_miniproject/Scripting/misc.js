if(localStorage.getItem('dev_ops') === 'on')
{
	var x = document.getElementsByTagName('body')[0].querySelectorAll('*');
	
	document.getElementsByTagName('body')[0].style.overflow = "scroll";

	for(var ctr = 0; x[ctr] !== undefined ; ctr++)
	{
		x[ctr].style.border = "1px solid black";  
	}
}