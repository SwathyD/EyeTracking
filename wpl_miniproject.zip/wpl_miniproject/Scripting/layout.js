document.getElementById('modals').addEventListener("click", page_down, false);

// document.getElementById('about_dash_txt').addEventListener('click', function(){
// 		add_action_with_string('support', 'About');
// 		redirect('about.html');
// }, false);

document.getElementById('acc_dash_txt').addEventListener('click', function(){
		add_action_with_string('support', 'Accounts');
		redirect('account.html');
}, false);

if(username()) selection();

else
{
	var path = window.location.href;

	if(path.charAt(path.length-10) !== 'i')
	{
		window.location.assign('index.html');
	}
}

if(localStorage.getItem("logged_user") !== '\0' && localStorage.getItem("logged_user")) 
{
	document.getElementById('menu_toggler').style.display = "flex";
	document.getElementById('menu_toggler').addEventListener('click', show_menu, false);
	document.getElementById('menu_premium').addEventListener('click', hide_menu, false);
	document.getElementById('dashboard').remove();
	document.getElementById('logo').style.paddingTop = "3%";

	// DASHBOARD OPTIONS
	
	document.getElementById('log_out').addEventListener('click', log_out, false);

	document.getElementById('e_paper').addEventListener('click', function(){
		add_action_with_element(this);
		redirect('paper_navigation.html');
	}, false);

	document.getElementById('quickies').addEventListener('click', function(){
		add_action_with_element(this);
		redirect('quickies.html');
	}, false);

	document.getElementById('statistics').addEventListener('click', function(){
		add_action_with_element(this);
		advanced_dash();
	}, false);

	document.getElementById('dash_close').addEventListener('click', hide_menu, false);
	document.getElementById('about').addEventListener('click', function(){
		add_action_with_element(this);
		redirect('about.html');
	}, false);
}	

// CLEAR THE USERNAME ON CLICKING LOGO
document.getElementById('logo').addEventListener('click', mem_clr, false);

// Capture the actions with the NavBar

document.getElementById('navbar').addEventListener('click', function(event){
	if(event.target.getAttribute('data-type') && (event.target.getAttribute('data-val') !== 'Home'))
	{
		add_action_with_element(event.target);
	}
}, false);


function selection()
{	
	var activated = document.getElementById('active');
	var link = activated.getElementsByTagName('a')[0];
	link.style.color = '#0eaeb2';
	activated.style.backgroundColor = 'transparent';
}

// CLEAR THE USERNAME

function mem_clr() {
	localStorage.removeItem("username");
}

function page_up(event)
{
	var elem = event.currentTarget;

	// document.getElementById('page_'+elem.id).style.display = "block";
	// document.getElementById('card_click_content').className = "yes_click";
	
	// setTimeout(function(){
	// 	document.getElementById('page_'+elem.id).style.top = "5%";
	// 	document.getElementById('card_click_content').style.opacity = "1";
	// }, 0);

	localStorage.setItem('currently_viewing', ('page_'+elem.id));
}

function page_down(event)
{
	if(event.target == event.currentTarget)
	{	
		// var elem = document.getElementById(localStorage.getItem('currently_viewing'));
		// var overlay = event.currentTarget;	

		// if(document.getElementById('about_img'))
		// {
		// 	document.getElementById('about_img').style.opacity = "0";
		// 	document.getElementById('info').style.opacity = "0";
			
		// 	setTimeout(function(){
		// 		document.getElementById('about_img').style.display = "none";
		// 		document.getElementById('info').style.display = "none";
		// 	}, 300);
		// }


		// elem.style.top = "100%";
		
		// setTimeout(function(){
		// 	overlay.style.opacity = "0";
		// }, 100);

		// setTimeout(function(){
		// 	elem.style.display = "none";
		// }, 400);

		// setTimeout(function(){
		// 	overlay.className = "no_click";
		// }, 400);
		
		// add_action_with_element(elem);

		var counter = parseInt(localStorage.getItem(username()+'_cards_read'));
		localStorage.setItem(username()+'_cards_read', ++counter);

		localStorage.setItem('currently_viewing', null);
	}
}

function show_menu()
{
	document.getElementById('menu_premium').className = "yes_show";

	setTimeout(function(){
		document.getElementById('menu_wrapper').style.left = "0%";
	}, 0);
}

function hide_menu(event)
{
	if(event.target === event.currentTarget)
	{
		hide_advanced_dash();
		document.getElementById('menu_wrapper').style.left = "-30%";
	
		setTimeout(function(){
			document.getElementById('menu_premium').className = "not_show";
		}, 200);
	}
}

function log_out()
{
	add_action_with_element(this);
	localStorage.setItem('logged_user', '\0');
	window.location.reload();
}


// News Flash

var news = new Array(10);

function flash_changer(string)
{
	var flash = document.getElementById('flash_news');
	flash.style.opacity = "0";

	setTimeout(function(){
		flash.innerHTML = string;
	}, 500);

	setTimeout(function(){
		flash.style.opacity = "1";
	}, 600);
}

function flash_controller()
{
	news[0] = "Hi "+username()+"!";
	var a = 0;

	setTimeout(function(){
		flash_changer(news[a]);
		a++;
	}, 1000);

	setInterval(function(){
		flash_changer(news[a]);
		a++;
		if(a >= 10) a = 1;
	}, 4000);
}

function advanced_dash()
{
	document.getElementById('dash_close').removeEventListener('click', hide_menu, false);
	document.getElementById('dash_close').addEventListener('click', hide_advanced_dash, false);

	document.getElementById('integral_content').style.opacity = "0";
	document.getElementById('advanced_content').style.opacity = "1";

	setTimeout(function(){
		document.getElementById('advanced_content').style.display = "flex";	
		document.getElementById('integral_content').style.display = "none";

		document.getElementById('e_paper').style.opacity = "0";
		document.getElementById('quickies').style.opacity = "0";
		document.getElementById('settings').style.opacity = "0";
		document.getElementById('statistics').style.opacity = "0";
		document.getElementById('about').style.opacity = "0";
		document.getElementById('log_out').style.opacity = "0";		
	}, 200);

	setTimeout(function(){		
		document.getElementById('statistics_title').style.opacity = "1";
	}, 225);
	
	setTimeout(function(){
		document.getElementById('time_online_wrapper').style.opacity = "1";
		document.getElementById('time_online').textContent = formatted_time_online();
	}, 250);

	setTimeout(function(){
		document.getElementById('cards_read_wrapper').style.opacity = "1";
		document.getElementById('cards_read').textContent = localStorage.getItem(username()+'_cards_read');
	}, 275);
		
	setInterval(function(){
		document.getElementById('time_online').textContent = formatted_time_online();
	}, 1000);
}

function hide_advanced_dash()
{

	document.getElementById('dash_close').removeEventListener('click', hide_advanced_dash, false);
	document.getElementById('dash_close').addEventListener('click', hide_menu, false);
	
	document.getElementById('advanced_content').style.opacity = "0";
	document.getElementById('integral_content').style.opacity = "1";

	setTimeout(function(){
		document.getElementById('advanced_content').style.display = "none";
		document.getElementById('integral_content').style.display = "flex";
	
		document.getElementById('advanced_content').style.opacity = "0";
		document.getElementById('statistics_title').style.opacity = "0";
		document.getElementById('cards_read_wrapper').style.opacity = "0";
		document.getElementById('time_online_wrapper').style.opacity = "0";
	}, 200);

	setTimeout(function(){
		document.getElementById('e_paper').style.opacity = "1";
	}, 215);

	setTimeout(function(){
		document.getElementById('quickies').style.opacity = "1";
	}, 230);

	setTimeout(function(){
		document.getElementById('settings').style.opacity = "1";
	}, 245);

	setTimeout(function(){
		document.getElementById('statistics').style.opacity = "1";
	}, 260);

	setTimeout(function(){
		document.getElementById('about').style.opacity = "1";
	}, 275);

	setTimeout(function(){
		document.getElementById('log_out').style.opacity = "1";
	}, 290);
	
}	