document.addEventListener("DOMContentLoaded", function(){
	
	setTimeout(function(){
		document.getElementById('body').style.opacity = "1";
	}, 0);

	var start = 0;
	var end = localStorage.getItem(username()+"_action_counter");

	for(; start < end; start++)
	{
		add_event(username()+"_action_"+start+"_");
	}

	document.getElementsByClassName('history_item_wrapper')[0].style.border = "2px solid green";
	document.getElementsByClassName('history_item_wrapper')[0].style.marginTop = "50px";
},false);

function add_event(prefix) {
	
	var time = format_this_time(localStorage.getItem(prefix+"time"));
	var content = string_classifier(prefix+"type", prefix+"val");

	var package = create_block(time, content);
	var parent = document.getElementById('user_history');

	parent.insertBefore(package, parent.getElementsByClassName('history_item_wrapper')[0]);
}

function create_block(taime, value)
{
	var base = document.createElement('div');
	var time = document.createElement('div');
	var content = document.createElement('div');

	base.className = "history_item_wrapper";
	time.className = "history_item_time";
	content.className = "history_item_conten";
	content.innerHTML = value;
	time.innerHTML = taime;

	base.appendChild(time);
	base.appendChild(content);

	return base;
}

function string_classifier(type, val)
{
	type = localStorage.getItem(type);
	val = localStorage.getItem(val);

	var msg;


	switch(type)
	{
		case "card" : msg = 'Read an article : <em class = "focus" >'+val+'</em>';
			break;

		case "nav" : msg = 'Headed to <em class = "focus">'+val+'</em>'; 
			break;

		case "self" : msg = '<em class = "focus">'+username()+'</em>&nbsp;'+val;
			break;

		case "caption" : msg = 'You clicked on the caption (Remember ? That text with blinking heart)';
			break;

		case "support" : msg = 'Used the <em>diginews</em> <em class = "focus">'+val+'</em> section';
			break;

		case "statistics" : msg = 'Saw some quirky <em class = "focus">'+val+'</em>';
			break;

		case "settings" : msg = 'Played with the <em class = "focus">'+val+'</em>';
			break;

		case "quickies" : msg = 'Viewed the <em class = "focus">Quickies</em>';
			break;

		case "e_paper" : msg = 'You read today\'s <em class = "focus"'+val+'</em>';
			break;

		default : msg = "Something occured that I don't Remember";
			break;
	}

	return msg;
}

function change()
{
	document.getElementById('tnc').style.display = 'none';

	if(localStorage.getItem("logged_user") !== '\0' && localStorage.getItem("logged_user"))
	{
		document.getElementById('user_history').style.display = "block";
	}

	else
	{
		document.getElementById('else').style.display = "flex";
	}
}