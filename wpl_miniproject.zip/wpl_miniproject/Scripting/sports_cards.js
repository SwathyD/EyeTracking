var cards = new Array();

cards[0] = new make_card("injury", "png", "Andre Gomes Suffers Horror Ankle Injury", "Everton midfielder Andre Gomes' serious injury and Tottenham forward Son Heung-min's tears overshadowed their teams' 1-1 draw in the Premier League on Sunday..");
cards[1] = new make_card("ipl", "png", "BCCI plans game-changer in IPL", "BCCI are looking to take it one step further by bringing in the concept of Power Player in the next edition of the cash-rich league. Teams will be allowed to substitute a player at the fall of a wicket or..");
cards[2] = new make_card("lewis-hamilton", "jpg", 'Lewis Hamilton Wins Sixth F1 World Title', "Lewis Hamilton clinched his sixth world title, but not in the style he hoped for on Sunday when he finished second behind his triumphant Mercedes team-mate Valtteri Bottas...");
cards[3] = new make_card("rani", "jpg", "Inspirational Rani Rampal remains a class above all", "Whichever side of that argument you are on, whenever there is a discussion about India's greatest hockey players, no list can be made without Rani Rampal's name on it.");	

for(var a = 0; a <= 3; a++)
{
	add_elem(cards[a], a);
}

for(var a = 0; a <= 3; a++){
	document.getElementById('card_'+a).addEventListener("click", page_up, false);
}

// FLASH ARTICLES

news[1] = "India vs Bangladesh: Cyclone threat looming over Rajkot T20I";
news[2] = "Nadal returns to number one in spite of Djokovic win in Paris";
news[3] = "Srikanth pulls out; Sindhu, Saina eye title at China Open";
news[4] = "Jadhav, Nadeem help India B lift Deodhar Trophy";
news[5] = "Papua New Guinea ready to be cricket's next fairytale story";
news[6] = "Manchester City skipper David Silva set to miss Liverpool clash";
news[7] = "F1: You deserve it all, Sebastian Vettel tells Lewis Hamilton";
news[8] = "Shubman Gill becomes youngest player to captain in Deodhar Trophy final";
news[9] = "Chelsea gets November 20 court date for FIFA transfer ban appeal";

flash_controller();