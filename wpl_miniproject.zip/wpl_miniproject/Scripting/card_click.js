function page_up(event)
{
	var elem = event.currentTarget;

	document.getElementById('page_'+elem.id).style.display = "block";
	document.getElementById('card_click_content').className = "yes_click";
	document.getElementById('card_click_content').style.opacity = "1";
	
	setTimeout(function(){
		document.getElementById('page_'+elem.id).style.top = "5%";
	}, 0);

	localStorage.setItem('currently_viewing', ('page_'+elem.id));
}

function page_down(event)
{
	if(event.target == event.currentTarget)
	{	
		var elem = document.getElementById(localStorage.getItem('currently_viewing'));
		var overlay = event.currentTarget;	

		elem.style.top = "100%";

		setTimeout(function(){
			elem.style.display = "none";
			overlay.style.opacity = "0";
		}, 750);

		setTimeout(function(){
			overlay.className = "no_click";
		}, 1150);

		localStorage.setItem('currently_viewing', null);
	}
}