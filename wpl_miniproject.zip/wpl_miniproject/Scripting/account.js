var sign_prefix = "sign_user"; 
var plate_log = 0;

var login = document.getElementsByClassName('active')[0];
var sign = document.getElementsByClassName('inactive')[0];
var nxt = document.getElementById('button_nxt');
var prev = document.getElementById('button_prev');

var regex = /[^A-Za-z]/g;

var error_empty_string = document.getElementById('empty_string');
var error_special_char = document.getElementById('special_char');
var error_unknown = document.getElementById('unrecognized_username');
var error_incorrect_password = document.getElementById('incorrect_password');
var name_text = document.getElementById('name_text');
var username_box = document.getElementById('username');
var pass_text = document.getElementById('pass_text');
var pass_box = document.getElementById('password');

var error_color = "red";
var error_color_border = "4px solid "+error_color;
var correct_color = "#36ff26";
var correct_color_border = "4px solid "+correct_color;

error_special_char.style.display = "none";
error_unknown.style.display = "none";

username_box.value = localStorage.getItem("username"); 

document.addEventListener("DOMContentLoaded", function(){
	setTimeout(function(){
		document.getElementById('body1').style.opacity = "1";
	}, 0);
}, false);

document.getElementById('continue').addEventListener("click", function(){
	document.getElementById('advice').style.bottom = "-100%";

	setTimeout(function(){
		document.getElementById('advice').style.display = "none";		
	}, 1000);

}, false);

login.addEventListener("click", function(){
		active_changer(login, sign, "log", "sign");
}, false);

sign.addEventListener("click", function(){
		active_changer(sign, login, "sign", "log");
}, false);

function active_changer(active, inactive, block, none)
{
	active.className = "active";
	inactive.className = "inactive";
	document.getElementById(none).style.display = "none";
	document.getElementById(block).style.display = "block";
}

pass_box.addEventListener("keyup", function(){
	correct_color_implementor(pass_text, pass_box);
	document.getElementById('empty_password').style.display = "none";
	error_incorrect_password.style.opacity = "0";
}, false);

username_box.addEventListener("keyup", function(){

	error_unknown.style.display = "none";

	if(!this.value){
		error_empty_string.style.opacity = "1";
		error_special_char.style.display = "none";
		error_color_implementor(name_text, username_box);		
		return;
	}

	else error_empty_string.style.opacity = "0";

	if(!this.value.match(regex))
	{
		error_special_char.style.display = "none";
		correct_color_implementor(name_text, username_box);
	}

	else 
	{
		error_special_char.style.display = "flex";
		error_special_char.style.opacity = "1";
		error_color_implementor(name_text, username_box);
	}

}, false);

prev.addEventListener('click', function(){
	move_back();
	plate_log--;
}, false);

nxt.addEventListener('click', function(){
	switch(plate_log)
	{
		case 0: name_plate(name_text, username_box, error_unknown);
			break;
		case 1: pass_plate(pass_text, pass_box, error_incorrect_password);
			break;
	}

}, false);

document.getElementById('explore').addEventListener('click', function(){
		add_action_with_element(this);
}, false);

document.addEventListener("mousemove", function(event){
	if(!plate_log) 
	{
		button_prev.style.visibility = "hidden";
	}

	if(plate_log == 1)
	{
		button_prev.style.visibility = "visible";
	}

	if(plate_log == 2)
	{
		document.getElementById('button_wrapper').style.display = "none";
	}

}, false);

function move_back()
{
	document.getElementById('name_wrapper').style.left = "0%";

	setTimeout(function(){
		document.getElementById('pass_wrapper').style.display = "none";
	}, 1000);
}

function name_plate(name_text, username_box, error_unknown)
{
	var index = log_check(username_box);

	if(index >= 0)
	{
		document.getElementById('name_wrapper').style.left = "-100%";
		document.getElementById('pass_wrapper').style.display = "flex";
		localStorage.setItem("captured_index_sign_user", index);
		plate_log++;
	}

	else 
	{
		error_unknown.style.display = "flex";
		error_unknown.style.opacity = "1";
		error_color_implementor(name_text, username_box);
	}
}

function pass_plate(pass_text, pass_box, error_incorrect_password)
{
	var user_pass = localStorage.getItem("sign_user_pass_"+localStorage.getItem("captured_index_sign_user"));

	if(user_pass == pass_box.value)
	{
		document.getElementById('pass_wrapper').style.left = "-100%";
		document.getElementById('logged_in_notice_wrapper').style.display = "flex";
		plate_log++;

		var person =  "sign_user_name_"+localStorage.getItem('captured_index_sign_user');

		localStorage.setItem('logged_user', person);

		person = localStorage.getItem(person);

		localStorage.setItem('username', person);
	}

	else if(!pass_box.value)
	{
		document.getElementById('empty_password').style.display = "flex";
		document.getElementById('empty_password').style.opacity = "1";
		error_color_implementor(pass_text, pass_box);	
	}

	else
	{
		error_incorrect_password.style.opacity = "1";
		error_color_implementor(pass_text, pass_box);	
	}
}

function error_color_implementor(text, border)
{
	text.style.color = error_color;
	border.style.borderBottom = error_color_border;
}

function correct_color_implementor(text, border)
{
	text.style.color = correct_color;
	border.style.borderBottom = correct_color_border;
}

function log_check(field)
{
	var lim = localStorage.getItem('sign_user_ctr');

	for(var a = 0; a < lim; a++)
	{
		if(localStorage.getItem('sign_user_name_'+a) == field.value) return a;
	}
	return -1;	
}

